NEW HORIZONS - ACTION SWORDPLAY AND FREE SAILING
Version 1.0

INSTALLATION
- Use a clean, unheadered Uncharted Waters - New Horizons (USA) SNES ROM
- Required ROM size: 2,097,152 bytes
- Required ROM CRC32: 3C3C63E6
- Apply NewHorizons_ActionSwordplay_FreeSailing_v10.bps with a BPS-compatible ROM patcher
- Save the result as a separate .sfc file and open it in your SNES emulator
- Patched ROM size: 4,194,304 bytes
- Patched ROM CRC32: C03C9C5B

FREE SAILING
- Steer in eight directions with the D-pad
- Continuous ship movement and camera scrolling replace tile-based movement
- Ship movement runs at half the original speed
- Wind, ship and crew still affect speed
- The bottom-right clock advances hour by hour with AM/PM while sailing
- Town time, visits and rest keep their original behavior
- Use the original sailing menus for anchoring and supplies
- Sailing pauses while you answer arrival questions or dismiss discovery messages

ACTION SWORDPLAY
- Real-time duels replace card selection
- All six attack and defense buttons appear beneath the equipment panels
- Original portraits, names, equipment panels and the blue/red balance bar remain
- Left/right footwork is slower for more deliberate dueling
- Both fighters stay planted during attacks, defenses and recovery
- Hits and clashes can still push fighters backward
- The opponent pursues and sometimes backs away
- Strength, swordfighting skill and equipped weapons and armor affect damage
- Heavier attacks can penetrate tougher defenses
- Attacks miss when the opponent is outside their reach
- Timed matching defenses cause zero-damage clashes
- Other active defenses reduce damage
- The balance bar starts at 100/100 and shifts as fighters take hits

DUEL CONTROLS - SNES BUTTONS
- Left: advance while idle
- Right: retreat while idle
- A: Thrust - quick attack with long reach and light damage
- Y: Lash - balanced speed, reach and damage
- B: Strike - slower close-range attack with heavy damage
- X: Parry
- R: Dodge
- L: Block
- Move into reach before attacking and release attack buttons to reposition
- Hold an attack to repeat after recovery
- Tap a defense to guard for about 0.3 seconds followed by about 0.2 seconds of recovery
- Holding a defense does not extend or repeat it
- Release and tap again after recovery
- Inputs during another committed action are ignored

MATCHING DEFENSES
- Thrust: Parry
- Lash: Block
- Strike: Dodge

CAMPAIGN AND SAVES
- New Otto campaigns begin with his original Short Sword and Leather Armor equipped
- Existing campaigns keep their equipment and can use the normal Equip menu
- Back up existing battery saves before changing ROMs
- If needed, give the battery save the same base filename as the patched ROM
- Start from the title screen or an in-game battery save rather than a save state from another ROM version
